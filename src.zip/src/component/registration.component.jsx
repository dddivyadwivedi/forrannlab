import {React , useState} from 'react'
import './registration.styles.css'
import Axios from 'axios'

function Register() {
    const [change , setChange] = useState({
        name : '', 
        email : '', 
        password : '', 
        file : '',
        cloudLink : '',

    })
    const [fileUrl , setFileUrl] = useState('')

    const getFile =async (e)=>{
        const files = e.target.files
        const data = new FormData()
        data.append('file' , files[0])
        data.append('upload_preset' ,'userfiles')
        await fetch('https://api.cloudinary.com/v1_1/myregisterform/upload',{
            method: 'POST',
            body : data
        })
        .then(response =>{
            return response.json()
        })
        .then(data =>{
            setFileUrl(data.url)
        })

    }

    const handleChange = async e => {
        if(e.target.name === 'file'){
            getFile(e)
        }
        setChange(previous=>{
            return {
                ...previous ,
                [e.target.name] : e.target.value
            }
        })
    }
    
    const handleSubmit = (e)=>{
        e.preventDefault()
        change.cloudLink = fileUrl
        Axios.post('http://localhost:4000',change)
        .then(response =>{
            alert(response.data)
        })
        .catch(err =>{
            console.log(err)
        })
        alert('You are successfully registered with us')
    }
    return (
        
        <form className = 'container'  onSubmit={handleSubmit} method='post' encType='multipart/form-data'>   
         <input type='text' name='name' placeholder='Name' value={change.name} className='field' onChange={handleChange} />
         <input type='email' name='email' placeholder='Email' value={change.email} className='field' onChange={handleChange} />
         <input type='password' name='password' placeholder='Password' value={change.password} className='field' onChange={handleChange} />
         <input type='file' name='file' value={change.file} onChange={handleChange} />
         <button>Submit</button>
        </form>
    )
}
export default Register
